﻿
using var game = new Chessgame.Game1();
game.Run();
